<?php
/*
* MDKanban
*
* @link              https://milenio.com/
* @since             1.0.0
* @package           MDKanban
*
* @MDKanban
* Plugin Name:       MDKanban
* Plugin URI:        https://github.com/009Benny/MDKanban
* Description:       Plugin de Administracion Kanban para Wordpress
* Version:           1.0
* Author:             © GRUPO MILENIO
* Author URI:        http://www.milenio.com/
* Text Domain:       MDKanban
*/

require_once plugin_dir_path( __FILE__ ) . 'Database/taskDB.php';
require_once plugin_dir_path( __FILE__ ) . 'Views/Modules/labels.php';
require_once plugin_dir_path( __FILE__ ) . 'Views/Modules/Forms/options.php';
require_once plugin_dir_path( __FILE__ ) . 'Views/Modules/Forms/task.php';
require_once plugin_dir_path( __FILE__ ) . 'Views/Modules/Forms/user.php';
require_once plugin_dir_path( __FILE__ ) . 'Database/query.php';
require_once plugin_dir_path( __FILE__ ) . 'Views/Class/md_Table_WP.php';

register_activation_hook( __FILE__, 'md_create_tables' );
// register_deactivation_hook(__FILE__, 'md_remove_tables' );

add_shortcode('create_task', 'MDFormTask');
add_shortcode('create_user', 'MDFormUser');
add_shortcode('create_options', 'MDFormOptions');
add_shortcode('table_users', 'TableUsers');

/*   AGREGAR CSS     */
function add_kanban_css(){
  wp_register_style( 'MDKanbanStyle', plugin_dir_url( __FILE__ ).'css/main.css', array());
  wp_enqueue_style('MDKanbanStyle');
}
add_action('wp_enqueue_scripts', 'add_kanban_css', 99);
add_action('admin_head', 'add_kanban_css');

/*    AGREGAS JAVASCRIPT    */
function add_MDscript() {
  // wp_enqueue_script('MDKanbanScript',plugin_dir_url( __FILE__ ).'/js/MDShortcodeProduct.js', array('jquery'));
  wp_enqueue_script('MDKanbanInputs',plugin_dir_url( __FILE__ ).'/js/Groups/Inputs.js', array('jquery'));
  wp_localize_script('MDKanbanInputs', 'obj_ajax', array('ajax_url' => admin_url('admin-ajax.php')));
}
add_action('wp_enqueue_scripts', 'add_MDscript');
add_action('admin_head', 'add_MDscript');

/*     AGREGAR FUNCIONES PHP A AJAX     */
add_action('wp_ajax_InsertMDUser', 'InsertMDUser');
add_action('wp_ajax_PrintUserForm', 'PrintUserForm');
/*DESCOMENTAR SOLO SI CUALQUIERA PUEDE AGREGAR USUARIOS*/
add_action('wp_ajax_nopriv_InsertMDUser', 'InsertMDUser');
add_action('wp_ajax_nopriv_PrintUserForm', 'PrintUserForm');

//Crear menú de administración del plugin MDKanban

add_action('admin_menu','MDKanban_admin_menu');

/* MENU MDKANBAN PLUGIN */
function MDKanban_admin_menu()
{
  //add_menu_page(page_title,menu_title,capability,menu_slug, function, icon_url,position)
  add_menu_page('MDKanban','MDKanban','manage_options','MDKanban_plugin','MDKanban_admin_menu_function','dashicons-sticky');
  add_submenu_page('MDKanban_plugin','MDKanban Task','Task','manage_options','MDkanban_task_submenu5','MDKanban_task_function');
  add_submenu_page('MDKanban_plugin','MDKanban Users','Users','manage_options','MDkanban_users_submenu3','MDKanban_users_function');
  add_submenu_page('MDKanban_plugin','MDKanban Roles','Roles','manage_options','MDKanban_roles_submenu1','MDKanban_roles_function');
  add_submenu_page('MDKanban_plugin','MDKanban Status','Status','manage_options','MDkanban_status_submenu2','MDKanban_status_function');
  add_submenu_page('MDKanban_plugin','MDKanban Frecuency','Frecuency','manage_options','MDkanban_frecuency_submenu4','MDKanban_frecuency_function');
}

function MDKanban_admin_menu_function(){
  echo "Pagina principal MDKanban";
}

function MDKanban_task_function(){
  echo "Apartado Task";
}

function MDKanban_users_function(){
  $table_name = 'md_user';
  $columns = array(
    "id" => "ID",
    "name" => "Nombre",
    "id_role" => "Rol",
    "email" => "Correo electronico",
  );
  md_createTable($table_name, $columns);
}

function MDKanban_roles_function(){
  $table_name = 'md_role';
  $columns = array(
    "id" => "ID",
    "name" => "Slug",
  );
  md_createTable($table_name, $columns);
}
function MDKanban_status_function(){
  $table_name = 'md_status';
  $columns = array(
    "id" => "ID",
    "name" => "Slug",
  );
  md_createTable($table_name, $columns);
}

function MDKanban_frecuency_function(){
  $table_name = 'md_frecuency';
  $columns = array(
    "id" => "ID",
    "name" => "Slug",
  );
  md_createTable($table_name, $columns);
}

?>
