<?php
if (! class_exists ('WP_List_Table')){
  require_once(ABSPATH . 'wp-admin/includes/class-wp-list-table.php');
}
if (! class_exists ('MDKanbanTable')){
  class MDKanbanTable extends WP_List_Table {

    public function md_prepare_items($table_name = '', $columns = ''){
      // ORDENAR FILAS POR
      $orderby = isset($_GET['orderby']) ? trim($_GET['orderby']) : "";
      $order = isset($_GET['order']) ? trim($_GET['order']) : "";
      // BUSCAR RESULTADOS
      $search_term = isset($_POST['s']) ? trim($_POST['s']) : "";
      //HACER CONSULTA A LA BASE DE DATOS
      $results = sql_get_columns('*', $table_name);
      $this->items = $this->transform_result($results);
      //TRAER COLUMNAS
      $columns = $this->md_get_columns($columns);
      //TRAER UN ARRAY CON LAS COLUMNAS QUE SE QUIEREN OCULTAR
      $hidden = $this->get_hidden_columns();
      //TRAER UN ARRAY CON LAS COLUMNAS QUE AL DAR CLIC AL NOMBRE
      //DE LA COLUMNA, CAMBIE DE ORDEN ASCENDENTE, DESCENDENTE, O
      //NORMAL
      $sortable = $this->get_sortable_columns();
      $this->_column_headers = array($columns, $hidden, $sortable);
    }

    public function prepare_items(){
      // ORDENAR FILAS POR
      $orderby = isset($_GET['orderby']) ? trim($_GET['orderby']) : "";
      $order = isset($_GET['order']) ? trim($_GET['order']) : "";
      // BUSCAR RESULTADOS
      $search_term = isset($_POST['s']) ? trim($_POST['s']) : "";
      //HACER CONSULTA A LA BASE DE DATOS
      $results = sql_get_columns('*', 'wp_post');
      $this->items = $this->transform_result($results);
      //TRAER COLUMNAS
      $columns = $this->get_columns();
      //TRAER UN ARRAY CON LAS COLUMNAS QUE SE QUIEREN OCULTAR
      $hidden = $this->get_hidden_columns();
      //TRAER UN ARRAY CON LAS COLUMNAS QUE AL DAR CLIC AL NOMBRE
      //DE LA COLUMNA, CAMBIE DE ORDEN ASCENDENTE, DESCENDENTE, O
      //NORMAL
      $sortable = $this->get_sortable_columns();
      $this->_column_headers = array($columns, $hidden, $sortable);
    }
    public function transform_result($all_posts){
      $posts_array = array();
      if (count($all_posts) > 0) {

          foreach ($all_posts as $index => $post) {
            $posts_array[] = array(
                "id" => $post->id,
                "name" => $post->name,
                "id_role" => $post->id_role,
                "email" => $post->email,
            );
          }
      }
      return $posts_array;
    }
    //function default
    public function get_columns(){

    }

    public function md_get_columns($columns) {
        $array_columns = array();
        $array_columns['cb'] = '<input type="checkbox"/>';
        foreach ($columns as $key => $value) {
          $array_columns[$key] = $value;
        }
        return $array_columns;
    }

    public function get_hidden_columns() {
        return array("");
    }

    public function get_sortable_columns() {
        return array(
            "id" => array("id", true),
            // "email" => array("email", false)
        );
    }

    public function column_default($item, $column_name) {

        switch ($column_name) {

            case 'id':
            case 'name':
            case 'id_role':
            case 'email':
                return $item[$column_name];
            default:
                return "no value";
        }
    }

    function column_cb($item){
      return sprintf(
        '<input type="checkbox" name="role"[] value="%s"/>',$item['ID']
      );
    }
  }
}

function md_createTable($table_name, $columns){
  ob_start();
  $owt_table = new MDKanbanTable();
  $owt_table->md_prepare_items($table_name, $columns);
  echo '<h2>Tabla de Usuarios</h2>';
  echo "<form method='post' name='frm_search_post' action='" . $_SERVER['PHP_SELF'] . "?page=owt-list-table'>";
  $owt_table->search_box("Search Post(s)", "search_post_id");
  echo "</form>";

  $owt_table->display();
  $template = ob_get_contents();
  ob_end_clean();
  echo $template;
}
?>
